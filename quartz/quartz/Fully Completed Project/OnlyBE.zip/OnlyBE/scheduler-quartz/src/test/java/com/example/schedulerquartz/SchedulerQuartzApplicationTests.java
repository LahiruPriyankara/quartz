package com.example.schedulerquartz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedulerQuartzApplicationTests {

	@Test
	void contextLoads() {
	}

}
