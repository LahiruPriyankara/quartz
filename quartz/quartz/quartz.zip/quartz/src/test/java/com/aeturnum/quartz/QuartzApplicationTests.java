package com.aeturnum.quartz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuartzApplicationTests {

	@Test
	void contextLoads() {
	}

}
