package com.example.schedulerquartz.quartz.utils;

public enum JobGroupEnum {
	CRONJOB, SIMPLETRIGGER;
}
