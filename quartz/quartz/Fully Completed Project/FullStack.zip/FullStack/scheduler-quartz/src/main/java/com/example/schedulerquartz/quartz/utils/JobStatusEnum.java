package com.example.schedulerquartz.quartz.utils;

public enum JobStatusEnum {
	CREATED_SCHEDULED, EDITED_SCHEDULED, JOB_STARTED, JOB_PAUSED, JOB_RESUMED;
}
